#include "svdpi.h"
const float sum_fp(const float A, const float B)
{  
    return A+B;
}
